window.ATK_VERSION={"version":"from-base-provider-lists-2026-01-08","generatedAt":"2026-01-08T21:56:58.536Z"};
